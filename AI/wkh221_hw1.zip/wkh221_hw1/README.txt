I have implemented A* and BFT Algorithms. 
No special instructions for running both of them. 
I followed the guidelines in the homework. 
